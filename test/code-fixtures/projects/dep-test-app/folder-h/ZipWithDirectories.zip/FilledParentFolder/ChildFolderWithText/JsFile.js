export class AnotherGenericClass {
	subtract9(p) {
		return p - 9;
	}
}
